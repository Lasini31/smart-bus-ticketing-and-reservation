package com.STAR.busmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
